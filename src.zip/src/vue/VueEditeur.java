package vue;


public class VueEditeur extends VueJeu
{
	@Override
	public String getFXML()
	{
		return "/res/Editeur.fxml";
	}
}
